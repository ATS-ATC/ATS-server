package com.alucn.weblab.exception;

/**
 * @author haiqiw
 * 2017��6��6�� ����4:10:00
 * desc:WebAuthException
 */
public class WebAuthException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
