package com.alucn.casemanager.server.common.constant;


public class RtnCodeConstants {

	public static final String SUCCESS_CODE = "AAAAAA";
	
	public static final String EC_00000_CODE ="00000";
	public static final String EC_00000_MSG ="系统繁忙";
}
