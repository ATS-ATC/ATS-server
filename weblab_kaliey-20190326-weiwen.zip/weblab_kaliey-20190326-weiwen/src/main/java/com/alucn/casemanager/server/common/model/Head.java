package com.alucn.casemanager.server.common.model;


/**
 * message head
 * @author wanghaiqi
 *
 */
public class Head {

	private String reqType;
	private String response;
	
	
	public String getReqType() {
		return reqType;
	}
	public void setReqType(String reqType) {
		this.reqType = reqType;
	}
	public String getResponse() {
		return response;
	}
	public void setResponse(String response) {
		this.response = response;
	}
	
	
}
